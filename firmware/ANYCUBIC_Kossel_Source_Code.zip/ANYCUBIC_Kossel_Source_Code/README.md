# ANYCUBIC Kossel beta2/ANYCUBIC Kossel PLUS beta2
This branch based on RC 1.1.0.

Before upload, confirm the version of your printer by the '.PNG' picture.

Unsuitable modification or uploading may cause damage to the printer.

